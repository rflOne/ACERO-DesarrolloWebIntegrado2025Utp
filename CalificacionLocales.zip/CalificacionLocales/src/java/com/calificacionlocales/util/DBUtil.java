package com.calificacionlocales.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utilidad simple para obtener conexiones JDBC.
 * En producción preferible usar DataSource / connection pool.
 */
public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/calificacionlocales?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = ""; // ajusta si tienes contraseña

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL Driver no encontrado", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
