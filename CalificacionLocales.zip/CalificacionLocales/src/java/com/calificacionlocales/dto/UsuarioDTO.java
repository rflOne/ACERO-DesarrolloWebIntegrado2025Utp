package com.calificacionlocales.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class UsuarioDTO implements Serializable {

    private int id; // Mapeado a id_usuario en la DB
    private String nombre;
    private String email;
    private String password;
    private String rol; // 'administrador' o 'usuario'
    private int puntos;
    private Timestamp fechaRegistro;

    // Constructor vacío
    public UsuarioDTO() {
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
}
