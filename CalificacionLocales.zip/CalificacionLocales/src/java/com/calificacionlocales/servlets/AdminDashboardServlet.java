package com.calificacionlocales.servlets;

import com.calificacionlocales.dto.LocalDTO;
import com.calificacionlocales.fachada.AppFacade;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Lógica de Seguridad (Re-verificar rol "administrador")
        String rol = (String) request.getSession().getAttribute("rolUsuario");
        if (rol == null || !rol.equals("administrador")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // 2. Manejo de mensajes de estado (Ej: éxito en el registro de local)
        String status = request.getParameter("status");
        if ("success".equals(status)) {
            request.setAttribute("mensaje", "✅ Local registrado exitosamente.");
        }

        try {
            // LÓGICA DE NEGOCIO: OBTENER MÉTRICAS

            // 3. Obtener el total de locales
            int totalLocales = AppFacade.getInstance().contarLocales();

            // 4. Pasar el valor al JSP (coincide con ${totalLocales})
            request.setAttribute("totalLocales", totalLocales);

            int totalUsuarios = AppFacade.getInstance().contarUsuarios();
            // Lo pasamos al JSP con el nombre ${totalUsuarios}
            request.setAttribute("totalUsuarios", totalUsuarios);
            
            //Obtener los 10 locales
            List<LocalDTO> ultimosLocales = AppFacade.getInstance().listarUltimosLocales(10);
            // Pasamos la lista al JSP con el nombre 'ultimosLocales'
            request.setAttribute("ultimosLocales", ultimosLocales);

        } catch (Exception e) {
            // Manejo de errores de base de datos o fachada
            request.setAttribute("errorCarga", "⚠️ Error al cargar las métricas del dashboard: " + e.getMessage());
            // Si hay un error, aún mostramos el dashboard con el mensaje de error.
        }

        // 5. Reenviar al JSP del Dashboard (DEBE SER LA ÚNICA LLAMADA A forward)
        RequestDispatcher rd = request.getRequestDispatcher("/admin/dashboard.jsp");
        rd.forward(request, response);
    }
}