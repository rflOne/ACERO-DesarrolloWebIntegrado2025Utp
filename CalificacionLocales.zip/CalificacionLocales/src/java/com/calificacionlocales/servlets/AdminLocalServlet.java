package com.calificacionlocales.servlets;

import com.calificacionlocales.dto.LocalDTO;
import com.calificacionlocales.fachada.AppFacade;
import java.io.IOException;
import java.util.List; // Importar List
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.Part;

// Configuración para el manejo de archivos multipart/form-data
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50 // 50MB
)
@WebServlet("/admin/local")
public class AdminLocalServlet extends HttpServlet {

    private final AppFacade facade = AppFacade.getInstance(); // Inicializamos el Façade

    // --- LÓGICA DE SEGURIDAD Y VISTA (GET) ---
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. LÓGICA DE AUTENTICACIÓN (ROL ADMIN)
        String rol = (String) request.getSession().getAttribute("rolUsuario");

        if (rol == null || !rol.equals("administrador")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        // 🟢 LÓGICA UNIFICADA PARA LISTAR Y FILTRAR LOCALES
        if ("list".equals(action)) {

            // 1. Recoger y procesar parámetros de búsqueda
            String query = request.getParameter("query");
            String maxPriceParam = request.getParameter("maxPrice");
            Double maxPrice = null;

            // Bandera para saber si realmente se está aplicando un filtro
            boolean aplicandoFiltro = false;

            // Procesar el parámetro de precio
            if (maxPriceParam != null && !maxPriceParam.isEmpty()) {
                try {
                    maxPrice = Double.parseDouble(maxPriceParam);
                    aplicandoFiltro = true; // Hay filtro de precio
                } catch (NumberFormatException e) {
                    // Ignoramos el filtro si el valor es inválido
                }
            }

            // Verificar si hay filtro de texto
            if (query != null && !query.trim().isEmpty()) {
                aplicandoFiltro = true; // Hay filtro de texto
            }

            try {
                List<LocalDTO> localesList;

                // 2. Elegir el método del Façade a llamar
                if (aplicandoFiltro) {
                    // Si hay algún filtro (query o maxPrice válido), usamos el método filtrado.
                    localesList = facade.getAllLocales(query, maxPrice);

                    // Opcional: Mantener los parámetros en la request para mostrarlos en el JSP
                    request.setAttribute("currentQuery", query);
                    request.setAttribute("currentMaxPrice", maxPriceParam);

                } else {
                    // Si no se proporcionó ningún filtro (vienes directo del dashboard), 
                    // llamamos al método original sin parámetros.
                    localesList = facade.getAllLocales();
                }

                request.setAttribute("localesList", localesList);

                // 3. Redirige al JSP de gestión
                request.getRequestDispatcher("/admin/gestionLocales.jsp").forward(request, response);
                return;

            } catch (Exception e) {
                // Manejo de error y regreso al dashboard
                System.err.println("Error al listar/filtrar locales: " + e.getMessage());
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=list_db_error");
                return;
            }
        }

        // 2. LÓGICA PARA CARGAR DATOS EN MODO EDICIÓN
        if ("edit".equals(action)) {
            try {
                int idLocal = Integer.parseInt(request.getParameter("id"));
                LocalDTO localAEditar = facade.obtenerLocalPorId(idLocal);

                if (localAEditar != null) {
                    request.setAttribute("local", localAEditar);
                    request.setAttribute("modo", "editar");
                    request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
                    return;
                } else {
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=local_not_found");
                    return;
                }
            } catch (Exception e) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=invalid_id");
                return;
            }
        }

        // 🟢 LÓGICA PARA ELIMINAR EL LOCAL
        if ("delete".equals(action)) {
            String idParam = request.getParameter("id");
            if (idParam == null || idParam.isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=id_missing");
                return;
            }

            try {
                int idLocal = Integer.parseInt(idParam);

                // 1. Obtener la ruta de la imagen antes de la eliminación en DB
                LocalDTO localAborrar = facade.obtenerLocalPorId(idLocal);
                String rutaImagen = (localAborrar != null) ? localAborrar.getRutaImagen() : null;

                // 2. Llamar al Façade para la eliminación en cascada (DB: Valoraciones y Local)
                boolean eliminado = facade.eliminarLocalYValoraciones(idLocal);

                if (eliminado) {
                    // 3. Eliminar el archivo del servidor si existe y fue eliminado de DB
                    if (rutaImagen != null && !rutaImagen.isEmpty()) {
                        // Construye la ruta absoluta
                        String fullPathToDelete = getServletContext().getRealPath("") + File.separator + rutaImagen.replace("/", File.separator);
                        File oldFile = new File(fullPathToDelete);
                        if (oldFile.exists()) {
                            oldFile.delete(); // 🗑️ Eliminación física
                        }
                    }

                    // Redirigimos al dashboard con el parámetro de estado
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard?status=deleted");
                } else {
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=delete_failed");
                }
                return;

            } catch (Exception e) {
                // Manejo de error de formato (ID) o de base de datos
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=db_error");
                return;
            }
        }

        // 3. Lógica para modo "agregar" (default: si no hay acción o es inválida)
        request.setAttribute("modo", "agregar");
        request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
    }

    // --- LÓGICA DE PROCESAMIENTO (POST) ---
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Determinar el modo y crear el DTO
        String idParam = request.getParameter("id");
        boolean esEdicion = (idParam != null && !idParam.isEmpty());
        LocalDTO local = new LocalDTO();

        // Si es edición, intentamos asignar el ID. Si falla, redireccionamos con error.
        if (esEdicion) {
            try {
                local.setId(Integer.parseInt(idParam));
            } catch (NumberFormatException e) {
                request.setAttribute("error", "ID de local no válido.");
                request.setAttribute("modo", "editar");
                request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
                return;
            }
        }

        // 2. Mapear campos de texto (válido para ambos modos)
        try {
            local.setNombre(request.getParameter("nombre"));
            local.setDireccion(request.getParameter("direccion"));
            local.setDescripcion(request.getParameter("descripcion"));
            local.setCategoria(request.getParameter("categoria"));

            // Mapeo de campos numéricos
            local.setPrecioEstimado(Double.parseDouble(request.getParameter("precioEstimado")));
            local.setDescuentoPorcentaje(Integer.parseInt(request.getParameter("descuentoPorcentaje")));
        } catch (Exception e) {
            request.setAttribute("error", "Error en el formato de los campos numéricos.");
            request.setAttribute("local", local);
            request.setAttribute("modo", esEdicion ? "editar" : "agregar");
            request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
            return;
        }

        // 3. MANEJO DE LA IMAGEN
        try {
            Part filePart = request.getPart("imagen");
            String fileName = filePart.getSubmittedFileName();

            if (fileName != null && !fileName.isEmpty()) {
                // Si se sube una imagen nueva: Guardar y actualizar DTO
                String nombreUnico = System.currentTimeMillis() + "_" + fileName.replaceAll("\\s+", "_");
                String uploadPath = getServletContext().getRealPath("")
                        + File.separator + "recursos" + File.separator
                        + "imagenes" + File.separator + "locales";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }
                filePart.write(uploadPath + File.separator + nombreUnico);
                local.setRutaImagen("recursos/imagenes/locales/" + nombreUnico);

            } else if (esEdicion) {
                // Si es edición y NO se subió imagen: Mantener la ruta actual
                LocalDTO localExistente = facade.obtenerLocalPorId(local.getId());
                if (localExistente != null) {
                    local.setRutaImagen(localExistente.getRutaImagen());
                } else {
                    local.setRutaImagen(null);
                }
            } else {
                // Modo agregar y no hay imagen
                local.setRutaImagen(null);
            }
        } catch (Exception e) {
            request.setAttribute("error", "Error al procesar la imagen: " + e.getMessage());
            request.setAttribute("local", local);
            request.setAttribute("modo", esEdicion ? "editar" : "agregar");
            request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
            return;
        }

        // 4. LLAMAR AL FAÇADE (GUARDAR O ACTUALIZAR)
        try {
            boolean exito;

            if (esEdicion) {
                exito = facade.actualizarLocal(local);
            } else {
                exito = facade.registrarLocal(local);
            }

            if (exito) {
                // Éxito: Redirige al dashboard con status específico
                String status = esEdicion ? "updated" : "created";
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?status=" + status);
            } else {
                // Fallo al guardar/actualizar
                request.setAttribute("error", "Fallo al procesar la operación, la DB no se actualizó.");
                request.setAttribute("local", local);
                request.setAttribute("modo", esEdicion ? "editar" : "agregar");
                request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Error de base de datos
            request.setAttribute("error", "Error de base de datos: " + e.getMessage());
            request.setAttribute("local", local);
            request.setAttribute("modo", esEdicion ? "editar" : "agregar");
            request.getRequestDispatcher("/admin/nuevoLocal.jsp").forward(request, response);
        }
    }
}
