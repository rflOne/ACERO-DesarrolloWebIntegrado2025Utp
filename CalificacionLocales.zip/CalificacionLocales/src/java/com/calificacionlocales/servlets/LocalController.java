package com.calificacionlocales.servlets;

import com.calificacionlocales.dao.impl.LocalDAOImpl;
import com.calificacionlocales.dao.impl.ValoracionDAOImpl;
import com.calificacionlocales.dto.LocalDTO;
import com.calificacionlocales.dto.ValoracionDTO;
import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "LocalController", urlPatterns = {"/locales"})
public class LocalController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        LocalDAOImpl dao = new LocalDAOImpl();

        try {
            if (action == null || action.equals("list")) {
                List<LocalDTO> locales = dao.findAll();
                request.setAttribute("locales", locales);
                RequestDispatcher rd = request.getRequestDispatcher("locales/list.jsp");
                rd.forward(request, response);

            } else if (action.equals("detail")) {
                int id = Integer.parseInt(request.getParameter("id"));
                LocalDTO local = dao.findById(id);

                ValoracionDAOImpl valoracionDao = new ValoracionDAOImpl();
                List<ValoracionDTO> valoraciones = valoracionDao.findByLocalId(id);

                // ✅ Calcular el promedio
                double promedio = 0.0;
                if (valoraciones != null && !valoraciones.isEmpty()) {
                    double suma = 0.0;
                    for (ValoracionDTO v : valoraciones) {
                        suma += v.getPuntaje();
                    }
                    promedio = suma / valoraciones.size();
                }

                // ✅ Asignar el promedio al DTO
                local.setPromedioPuntaje(promedio);

                // ✅ Pasar los datos al JSP
                request.setAttribute("local", local);
                request.setAttribute("valoraciones", valoraciones);

                RequestDispatcher rd = request.getRequestDispatcher("locales/detail.jsp");
                rd.forward(request, response);
            }

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
