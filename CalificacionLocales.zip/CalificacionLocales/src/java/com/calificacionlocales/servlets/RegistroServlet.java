package com.calificacionlocales.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt; // 🔹 Encriptación segura

@WebServlet(name = "RegistroServlet", urlPatterns = {"/RegistroServlet"})
public class RegistroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener datos del formulario
        String nombre = request.getParameter("nombre");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm-password");

        // Validación básica de contraseñas
        if (!password.equals(confirmPassword)) {
            response.sendRedirect("registro.jsp?error=passwords_no_coinciden");
            return;
        }

        // Encriptar la contraseña
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Conexión a la base de datos
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/calificacionlocales";
            String user = "root";
            String dbPassword = "";
            conn = DriverManager.getConnection(url, user, dbPassword);

            // 🔍 Verificar si el email ya está registrado
            String checkEmailSql = "SELECT email FROM usuarios WHERE email = ?";
            pstmt = conn.prepareStatement(checkEmailSql);
            pstmt.setString(1, email);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Ya existe el email
                response.sendRedirect("registro.jsp?error=email_existente");
                return;
            }

            // 🔹 Cerrar el PreparedStatement anterior
            pstmt.close();

            // Insertar nuevo usuario
            String sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            pstmt.setString(2, email);
            pstmt.setString(3, hashedPassword);

            int filas = pstmt.executeUpdate();

            if (filas > 0) {
                // Registro exitoso → guardar sesión
                HttpSession session = request.getSession();
                session.setAttribute("nombreUsuario", nombre);
                session.setAttribute("usuarioLogeado", true);

                // Redirigir con mensaje de éxito
                response.sendRedirect("index.jsp?registro=exitoso");
            } else {
                response.sendRedirect("registro.jsp?error=no_se_pudo_registrar");
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(RegistroServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect("registro.jsp?error=no_se_pudo_registrar");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(RegistroServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("registro.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Servlet para el registro de usuarios con validación y encriptación segura";
    }
}

