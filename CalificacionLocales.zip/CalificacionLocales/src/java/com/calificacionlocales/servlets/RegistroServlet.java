package com.calificacionlocales.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "RegistroServlet", urlPatterns = {"/RegistroServlet"})
public class RegistroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener los parámetros del formulario de registro
        String nombre = request.getParameter("nombre");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm-password");

        // Simple validación en el servidor
        if (!password.equals(confirmPassword)) {
            response.sendRedirect("registro.html?error=passwords_no_coinciden");
            return;
        }
//conexion MYSQL
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean isSuccess = false; // Variable para rastrear el resultado del registro

        try {
            // 1. Cargar el driver de la base de datos
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2. Establecer la conexión
            String url = "jdbc:mysql://localhost:3306/calificacionlocales";
            String user = "root";
            String dbPassword = "";
            conn = DriverManager.getConnection(url, user, dbPassword);

            // 3. Crear la sentencia SQL
            String sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nombre);
            pstmt.setString(2, email);
            pstmt.setString(3, password);

            // 4. Ejecutar la sentencia
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Registro exitoso para el usuario: " + nombre);
                isSuccess = true;
                // Código para iniciar la sesión después de un registro exitoso
                HttpSession session = request.getSession();
                session.setAttribute("nombreUsuario", nombre);
                session.setAttribute("usuarioLogeado", true);
            } else {
                isSuccess = false;
            }

        } catch (ClassNotFoundException | SQLException ex) {
            // Manejar errores (ej. email duplicado)
            Logger.getLogger(RegistroServlet.class.getName()).log(Level.SEVERE, null, ex);
            isSuccess = false;
        } finally {
            // 5. Cerrar la conexión y los recursos
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(RegistroServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // --- Redirección final basada en el resultado ---
        if (isSuccess) {
            response.sendRedirect("index.jsp?registro=exitoso");
        } else {
            response.sendRedirect("registro.html?error=no_se_pudo_registrar");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("registro.html");
    }

    @Override
    public String getServletInfo() {
        return "Servlet para el registro de usuarios";
    }
}
