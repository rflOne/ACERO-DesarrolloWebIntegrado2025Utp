package com.calificacionlocales.servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "ValoracionServlet", urlPatterns = {"/ValoracionServlet"})
public class ValoracionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔹 1️⃣ Validar sesión
        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect("login.jsp?error=debes_iniciar_sesion");
            return;
        }

        int usuarioId = (int) session.getAttribute("usuarioId");
        int localId = Integer.parseInt(request.getParameter("localId"));
        int puntaje = Integer.parseInt(request.getParameter("puntaje"));
        String comentario = request.getParameter("comentario");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/calificacionlocales";
            String user = "root";
            String dbPassword = "";
            conn = DriverManager.getConnection(url, user, dbPassword);

            // 2️⃣ Insertar nueva valoración
            String sqlInsert = "INSERT INTO valoraciones (usuario_id, local_id, puntaje, comentario, fecha) VALUES (?, ?, ?, ?, NOW())";
            pstmt = conn.prepareStatement(sqlInsert);
            pstmt.setInt(1, usuarioId);
            pstmt.setInt(2, localId);
            pstmt.setInt(3, puntaje);
            pstmt.setString(4, comentario);
            pstmt.executeUpdate();
            pstmt.close();

            // 3️⃣ Recalcular promedio actualizado del local
            String sqlPromedio = "SELECT AVG(puntaje) AS promedio FROM valoraciones WHERE local_id = ?";
            pstmt = conn.prepareStatement(sqlPromedio);
            pstmt.setInt(1, localId);
            rs = pstmt.executeQuery();

            double promedio = 0;
            if (rs.next()) {
                promedio = rs.getDouble("promedio");
            }
            rs.close();
            pstmt.close();

            // 4️⃣ Actualizar el campo 'promedio' en la tabla locales
            String sqlUpdate = "UPDATE locales SET promedio = ? WHERE id = ?";
            pstmt = conn.prepareStatement(sqlUpdate);
            pstmt.setDouble(1, promedio);
            pstmt.setInt(2, localId);
            pstmt.executeUpdate();

            // 5️⃣ Redirigir al detalle con mensaje de éxito
            response.sendRedirect("LocalController?action=detail&id=" + localId + "&success=1");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("LocalController?action=detail&id=" + localId + "&error=1");
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
