package com.calificalocales.servlets;

import com.calificalocales.model.Usuario; // ¡Asegúrate de que este paquete sea correcto!
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime; // Necesario para el modelo Usuario
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/perfil")
public class PerfilServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // --- Configuración de DB (Asegúrate de que sean las mismas que en LoginServlet) ---
    private static final String DB_URL = "jdbc:mysql://localhost:3306/calificacionlocales";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // --- Métodos de Lógica (Simulación/DAO) ---
    
    // Método para obtener los datos COMPLETOS del usuario de la DB
    private Usuario obtenerUsuarioCompleto(int userId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Usuario usuario = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Nota: Agregamos puntos y fecha_registro al SELECT.
            String sql = "SELECT nombre, email, password, rol, puntos, fecha_registro FROM usuarios WHERE id_usuario = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Construye el objeto Usuario con todos los datos
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                String contrasena = rs.getString("password");
                String rol = rs.getString("rol");
                int puntos = rs.getInt("puntos");
                
                // Suponemos que la columna es DATETIME en MySQL y mapea a String. Si es TIMESTAMP o DATE, 
                // necesitarías usar java.sql.Timestamp/Date y convertir a LocalDateTime.
                String fechaRegistroStr = rs.getString("fecha_registro"); 
                LocalDateTime fechaRegistro = LocalDateTime.parse(fechaRegistroStr.replace(" ", "T")); // Conversión básica si es formato SQL 'YYYY-MM-DD HH:MM:SS'
                
                usuario = new Usuario(userId, nombre, email, contrasena, rol, puntos, fechaRegistro);
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PerfilServlet.class.getName()).log(Level.SEVERE, "Error al cargar usuario por ID", ex);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(PerfilServlet.class.getName()).log(Level.SEVERE, "Error al cerrar recursos DB", ex);
            }
        }
        return usuario;
    }
    
    private int obtenerTotalValoraciones(int userId) {
        // En un escenario real, esto consultaría una tabla de 'valoraciones'
        // Simulación:
        return 15; 
    }

    // --- GET: Mostrar el perfil ---
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        Integer usuarioId = null;
        Usuario usuarioActual = null;
        
        // 1. Verificar si hay un ID de usuario en la sesión (el que guarda el LoginServlet)
        if (session != null && session.getAttribute("usuarioId") instanceof Integer) {
            usuarioId = (Integer) session.getAttribute("usuarioId");
        }

        // 2. Si no hay ID o no está logueado, redirigir al login
        if (usuarioId == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        // 3. Obtener el objeto Usuario COMPLETO de la DB
        usuarioActual = obtenerUsuarioCompleto(usuarioId);
        
        if (usuarioActual == null) {
            // Esto sucede si el usuario existe en sesión pero no en DB (error grave)
            session.invalidate(); 
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=usuario_no_encontrado");
            return;
        }

        // 4. Cargar datos adicionales para la vista
        int totalValoraciones = obtenerTotalValoraciones(usuarioId);
        
        request.setAttribute("usuarioActual", usuarioActual);
        request.setAttribute("totalValoraciones", totalValoraciones);
        
        // Enviar a la vista JSP
        request.getRequestDispatcher("/perfilUsuario.jsp").forward(request, response);
    }

    // --- POST: Manejar las acciones (cambiar contraseña) ---
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Integer usuarioId = null;
        Usuario usuarioActual = null;

        if (session != null && session.getAttribute("usuarioId") instanceof Integer) {
            usuarioId = (Integer) session.getAttribute("usuarioId");
            usuarioActual = obtenerUsuarioCompleto(usuarioId);
        }

        if (usuarioActual == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        
        if (action != null && action.equals("changePassword")) {
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmNewPassword = request.getParameter("confirmNewPassword");

            // 1. Validaciones de la contraseña
            if (!newPassword.equals(confirmNewPassword)) {
                response.sendRedirect(request.getContextPath() + "/perfil?error=pass_mismatch");
                return;
            }
            
            // 2. Verificar contraseña actual con BCrypt (Usamos el atributo 'password' cargado desde la DB)
            if (!org.mindrot.jbcrypt.BCrypt.checkpw(currentPassword, usuarioActual.getContrasena())) { 
                 response.sendRedirect(request.getContextPath() + "/perfil?error=invalid_current_pass");
                 return;
            }

            // 3. Cambiar la contraseña en la DB
            if (actualizarContrasenaEnDB(usuarioId, newPassword)) {
                response.sendRedirect(request.getContextPath() + "/perfil?status=password_changed");
            } else {
                response.sendRedirect(request.getContextPath() + "/perfil?error=update_failed");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/perfil");
        }
    }
    
    // Método para actualizar la contraseña en la DB
    private boolean actualizarContrasenaEnDB(int userId, String newPassword) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        // HASH de la nueva contraseña
        String hashedNewPassword = org.mindrot.jbcrypt.BCrypt.hashpw(newPassword, org.mindrot.jbcrypt.BCrypt.gensalt());

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "UPDATE usuarios SET password = ? WHERE id_usuario = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, hashedNewPassword);
            pstmt.setInt(2, userId);

            return pstmt.executeUpdate() > 0;

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PerfilServlet.class.getName()).log(Level.SEVERE, "Error al actualizar contraseña", ex);
            return false;
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(PerfilServlet.class.getName()).log(Level.SEVERE, "Error al cerrar recursos DB", ex);
            }
        }
    }
}