package com.calificacionlocales.servlets;

import com.calificacionlocales.dto.UsuarioDTO; // Tendrás que crear esta clase
import com.calificacionlocales.fachada.AppFacade; // Asumimos que AppFacade tendrá los métodos de usuario
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admin/usuario") // Mapeo simple
public class AdminUsuarioServlet extends HttpServlet {

    private final AppFacade facade = AppFacade.getInstance(); // Fachada

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // --- 1. LÓGICA DE AUTENTICACIÓN (ROL ADMIN) ---
        String rol = (String) request.getSession().getAttribute("rolUsuario");
        if (rol == null || !rol.equals("administrador")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");

        // --- 2. LÓGICA PARA LISTAR Y FILTRAR USUARIOS ---
        if ("list".equals(action)) {
            
            // 2a. Recoger parámetros de búsqueda (similares a gestionUsuarios.jsp)
            String query = request.getParameter("query");
            String rolFiltro = request.getParameter("rol");

            // Si vienes directo del dashboard, 'query' y 'rolFiltro' serán null/vacíos.
            
            try {
                List<UsuarioDTO> usersList;
                
                // Llama al método del Façade para obtener todos los usuarios o aplicar filtros
                if ((query != null && !query.trim().isEmpty()) || (rolFiltro != null && !rolFiltro.isEmpty())) {
                    // Si hay filtros, usamos el método de búsqueda
                    usersList = facade.getAllUsuarios(query, rolFiltro);
                    request.setAttribute("currentQuery", query);
                    request.setAttribute("currentRol", rolFiltro);
                } else {
                    // Si no hay filtros, listamos todos
                    usersList = facade.getAllUsuarios(); 
                }

                request.setAttribute("usersList", usersList);
                
                // Redirige al JSP de gestión de usuarios
                request.getRequestDispatcher("/admin/gestionUsuarios.jsp").forward(request, response);
                return;

            } catch (Exception e) {
                // Manejo de error de DB
                e.printStackTrace(); 
                response.sendRedirect(request.getContextPath() + "/admin/dashboard?error=list_db_error");
                return;
            }
        }
        
        // --- 3. LÓGICA PARA MODO AGREGAR/EDITAR (Próximo paso) ---
        if ("add".equals(action) || "edit".equals(action)) {
            // Lógica para cargar nuevoUsuario.jsp (lo harás más adelante)
            response.sendRedirect(request.getContextPath() + "/admin/nuevoUsuario.jsp");
            return;
        }

        // --- 4. LÓGICA PARA MODO ELIMINAR (Próximo paso) ---
        if ("delete".equals(action)) {
            // Lógica de eliminación (lo harás más adelante)
            response.sendRedirect(request.getContextPath() + "/admin/dashboard?status=deleted");
            return;
        }

        // Default: Si no hay acción o es inválida, redirecciona al listado
        response.sendRedirect(request.getContextPath() + "/admin/usuario?action=list");
    }

    // El doPost manejará las peticiones de creación y edición (no es necesario ahora)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // O implementar lógica de save/update
    }
}