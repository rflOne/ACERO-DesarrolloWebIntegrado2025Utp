package com.calificacionlocales.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean loginExitoso = false;

        try {
            // 1️⃣ Conectar a la base de datos
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/calificacionlocales";
            String user = "root";
            String dbPassword = "";
            conn = DriverManager.getConnection(url, user, dbPassword);

            // 2️⃣ Buscar usuario por email (incluimos el id)
            String sql = "SELECT id_usuario, nombre, password, rol FROM usuarios WHERE email = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                int usuarioId = rs.getInt("id_usuario");
                String nombreUsuario = rs.getString("nombre");
                String passwordHasheada = rs.getString("password");
                String rolUsuario = rs.getString("rol");

                // 3️⃣ Verificar la contraseña con BCrypt
                if (BCrypt.checkpw(password, passwordHasheada)) {
                    loginExitoso = true;

                    // 4️⃣ Crear sesión y guardar datos del usuario
                    HttpSession session = request.getSession();
                    session.setAttribute("usuarioId", usuarioId);       // ✅ NECESARIO PARA VALORACIONES
                    session.setAttribute("nombreUsuario", nombreUsuario);
                    session.setAttribute("usuarioLogeado", true);
                    session.setAttribute("rolUsuario", rolUsuario);
                }
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // 5️⃣ Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // 6️⃣ Redirección según resultado
        if (loginExitoso) {
            response.sendRedirect("index.jsp?login=exitoso");
        } else {
            response.sendRedirect("login.jsp?error=credenciales_invalidas");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login.html");
    }
}
