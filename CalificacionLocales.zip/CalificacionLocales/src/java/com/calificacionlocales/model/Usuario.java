package com.calificalocales.model; 
// ¡IMPORTANTE! Asegúrate de que este paquete coincida con el import en tu PerfilServlet.java

import java.time.LocalDateTime; // Clase para manejar la fecha de registro

public class Usuario {

    private int id;
    private String nombre;
    private String email;
    private String contrasena; // Solo para uso interno (nunca exponer en la vista)
    private String rol; // Ejemplo: "usuario", "administrador"
    private int puntos; // Puntos de contribución
    private LocalDateTime fechaRegistro; // Fecha en que se registró

    // Constructor vacío (necesario para muchas herramientas ORM o frameworks)
    public Usuario() {
    }

    // Constructor completo (útil al recuperar un usuario de la DB)
    public Usuario(int id, String nombre, String email, String contrasena, String rol, int puntos, LocalDateTime fechaRegistro) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.contrasena = contrasena;
        this.rol = rol;
        this.puntos = puntos;
        this.fechaRegistro = fechaRegistro;
    }
    
    // Constructor de ejemplo para crear un nuevo usuario
    public Usuario(String nombre, String email, String contrasena, String rol) {
        this.nombre = nombre;
        this.email = email;
        this.contrasena = contrasena;
        this.rol = rol;
        this.puntos = 0;
        this.fechaRegistro = LocalDateTime.now();
    }

    // ----------------------------------------------------
    // METODOS GETTERS Y SETTERS
    // ----------------------------------------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    // Opcional: Para facilitar la impresión del objeto
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", rol='" + rol + '\'' +
                ", puntos=" + puntos +
                '}';
    }
}