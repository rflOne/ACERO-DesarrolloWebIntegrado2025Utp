package com.calificacionlocales.dao;

import com.calificacionlocales.dto.LocalDTO;
import java.util.List;

public interface LocalDAO {

    
     //Busca todos los locales registrados.
     
    List<LocalDTO> findAll() throws Exception;

    //Busca un local por su ID.
    LocalDTO findById(int id) throws Exception;

    //Guarda un nuevo local en la base de datos.
    boolean save(LocalDTO local) throws Exception;
    
    //Cuenta el número total de locales registrados.
    public int countAll() throws Exception;
    
    //cuenta 10 ultimos locales
    List<LocalDTO> findLatest(int limit) throws Exception;
    
    public boolean update(LocalDTO local) throws Exception;
    
    List<LocalDTO> findFiltered(String query, Double maxPrice) throws Exception;
}
