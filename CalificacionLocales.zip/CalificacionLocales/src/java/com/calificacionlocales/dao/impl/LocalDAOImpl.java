package com.calificacionlocales.dao.impl;

import com.calificacionlocales.dao.LocalDAO;
import com.calificacionlocales.dto.LocalDTO;
import com.calificacionlocales.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LocalDAOImpl implements LocalDAO {

    @Override
    public List<LocalDTO> findAll() throws Exception {
        // 🚨 CORRECCIÓN 1: Agregar descripcion y ruta_imagen a la consulta SELECT
        String sql = "SELECT id, nombre, direccion, categoria, precio_estimado, descuento_porcentaje, descripcion, ruta_imagen FROM locales";
        List<LocalDTO> list = new ArrayList<>();

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                LocalDTO l = new LocalDTO();
                l.setId(rs.getInt("id"));
                l.setNombre(rs.getString("nombre"));
                l.setDireccion(rs.getString("direccion"));
                l.setCategoria(rs.getString("categoria"));
                l.setPrecioEstimado(rs.getDouble("precio_estimado"));
                l.setDescuentoPorcentaje(rs.getInt("descuento_porcentaje"));

                // 🚨 CORRECCIÓN 2: Mapear los nuevos campos al DTO
                l.setRutaImagen(rs.getString("ruta_imagen"));
                l.setDescripcion(rs.getString("descripcion"));

                list.add(l);
            }
        }
        return list;
    }

    @Override
    public LocalDTO findById(int id) throws Exception {
        String sql = "SELECT id, nombre, direccion, categoria, precio_estimado, descuento_porcentaje, ruta_imagen, descripcion FROM locales WHERE id = ?";
        LocalDTO l = null;

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    l = new LocalDTO();
                    l.setId(rs.getInt("id"));
                    l.setNombre(rs.getString("nombre"));
                    l.setDireccion(rs.getString("direccion"));
                    l.setCategoria(rs.getString("categoria"));
                    l.setPrecioEstimado(rs.getDouble("precio_estimado"));
                    l.setDescuentoPorcentaje(rs.getInt("descuento_porcentaje"));
                    l.setRutaImagen(rs.getString("ruta_imagen"));
                    l.setDescripcion(rs.getString("descripcion"));
                }
            }
        }
        return l;
    }

    @Override
    public boolean save(LocalDTO local) throws Exception {
        // ACTUALIZACIÓN: Incluir descripcion y ruta_imagen en la consulta INSERT
        // He incluido los campos que aparecen en tu DTO original por si son obligatorios.
        String sql = "INSERT INTO locales (nombre, direccion, categoria, descripcion, ruta_imagen, precio_estimado, descuento_porcentaje) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            // 1. Campos del formulario (Nombre, Dirección, Categoría)
            ps.setString(1, local.getNombre());
            ps.setString(2, local.getDireccion());
            ps.setString(3, local.getCategoria());

            // 2. Nuevos Campos (Descripción, Imagen)
            ps.setString(4, local.getDescripcion()); // Asume que LocalDTO tiene getDescripcion()
            ps.setString(5, local.getRutaImagen()); // ¡La ruta de la imagen que viene del Servlet!

            // 3. Campos antiguos (Precio y Descuento)
            // NOTA: Si estos campos no vienen del formulario de admin, 
            // asegúrate de que el DTO les tenga valores por defecto (ej: 0) o 
            // que la BD los acepte como NULL.
            ps.setDouble(6, local.getPrecioEstimado());
            ps.setInt(7, local.getDescuentoPorcentaje());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar local: " + e.getMessage());
            // Es importante relanzar la excepción para que el Façade pueda manejarla.
            throw new Exception("Error al guardar el local en la base de datos.", e);
        }
    }

    @Override
    public int countAll() throws Exception {
        // Consulta SQL simple para contar todas las filas en la tabla locales
        String sql = "SELECT COUNT(*) FROM locales";
        int count = 0;

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                // El resultado de COUNT(*) siempre estará en la primera columna (índice 1)
                count = rs.getInt(1);
            }
        }
        return count;
    }

    @Override
    public List<LocalDTO> findLatest(int limit) throws Exception {
        // Consulta para obtener los últimos N locales, ordenados por ID (o fecha) descendente
        // LIMIT 10 es específico de MySQL. Si usas otro DB, ajusta la sintaxis (ej: TOP N en SQL Server)
        String sql = "SELECT id, nombre, categoria, fecha_registro, ruta_imagen, fecha_registro FROM locales ORDER BY id DESC LIMIT ?";
        List<LocalDTO> list = new ArrayList<>();

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, limit); // Limitar a 10

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LocalDTO l = new LocalDTO();
                    l.setId(rs.getInt("id"));
                    l.setNombre(rs.getString("nombre"));
                    l.setCategoria(rs.getString("categoria"));

                    l.setFechaRegistro(rs.getDate("fecha_registro"));
                    // Necesitas la ruta para la vista previa en la tabla
                    l.setRutaImagen(rs.getString("ruta_imagen"));

                    list.add(l);
                }
            }
        }
        return list;
    }

    @Override
    public boolean update(LocalDTO local) throws Exception {
        // Nota: Excluimos 'ruta_imagen' de la actualización si no se cambia en el formulario.
        // Asumimos que la fecha_registro no se cambia.
        String sql = "UPDATE locales SET nombre=?, direccion=?, categoria=?, precio_estimado=?, "
                + "descuento_porcentaje=?, descripcion=? WHERE id=?";

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, local.getNombre());
            ps.setString(2, local.getDireccion());
            ps.setString(3, local.getCategoria());
            ps.setDouble(4, local.getPrecioEstimado());
            ps.setInt(5, local.getDescuentoPorcentaje());
            ps.setString(6, local.getDescripcion());

            // Clave: Usar el ID para el WHERE
            ps.setInt(7, local.getId());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            // Manejo de la excepción
            throw new Exception("Error SQL al actualizar el local con ID: " + local.getId(), e);
        }
    }

    public boolean delete(int id) throws Exception {
        // La sentencia DELETE requiere el ID como criterio
        String sql = "DELETE FROM locales WHERE id = ?";

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            // Asignar el parámetro ID
            ps.setInt(1, id);

            // Ejecutar la actualización (DELETE)
            int rowsAffected = ps.executeUpdate();

            // Devolver true si se eliminó al menos una fila
            return rowsAffected > 0;

        } catch (SQLException e) {
            // Re-lanzar la excepción para que la Fachada (AppFacade) la maneje
            throw new Exception("Error SQL al intentar eliminar el local con ID: " + id, e);
        }
    }

    @Override
    public List<LocalDTO> findFiltered(String query, Double maxPrice) throws Exception {
        List<LocalDTO> locales = new ArrayList<>();

        // Base de la consulta
        StringBuilder sql = new StringBuilder(
                "SELECT id, nombre, direccion, descripcion, categoria, ruta_imagen, "
                + "promedio, descuento_porcentaje, precio_estimado, fecha_registro " // <--- CAMBIO AQUÍ: Usar 'promedio'
                + "FROM locales WHERE 1=1"
        );

        // Lista para los parámetros de PreparedStatement
        List<Object> params = new ArrayList<>();

        // 1. FILTRO DE BÚSQUEDA POR TEXTO (Nombre o Categoría)
        boolean hasQuery = query != null && !query.trim().isEmpty();
        if (hasQuery) {
            sql.append(" AND (LOWER(nombre) LIKE ? OR LOWER(categoria) LIKE ?)");
            // Convertimos la búsqueda a minúsculas para coincidencia insensible a mayúsculas
            String searchPattern = "%" + query.trim().toLowerCase() + "%";
            params.add(searchPattern);
            params.add(searchPattern);
        }

        // 2. FILTRO POR PRECIO MÁXIMO
        boolean hasMaxPrice = maxPrice != null && maxPrice >= 0;
        if (hasMaxPrice) {
            sql.append(" AND precio_estimado <= ?");
            params.add(maxPrice);
        }

        // 3. ORDENACIÓN
        sql.append(" ORDER BY id DESC");

        // Ejecución de la consulta
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql.toString())) {

            // Asignar los parámetros dinámicamente
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LocalDTO local = new LocalDTO();
                    local.setId(rs.getInt("id"));
                    local.setNombre(rs.getString("nombre"));
                    local.setDireccion(rs.getString("direccion"));
                    local.setDescripcion(rs.getString("descripcion"));
                    local.setCategoria(rs.getString("categoria"));
                    local.setRutaImagen(rs.getString("ruta_imagen"));
                    local.setPrecioEstimado(rs.getDouble("precio_estimado"));

                    // Manejo de valores que pueden ser NULL en DB
                    local.setPromedioPuntaje(rs.getDouble("promedio"));
                    if (rs.wasNull()) {
                        local.setPromedioPuntaje(0.0);
                    }

                    local.setDescuentoPorcentaje(rs.getInt("descuento_porcentaje"));
                    if (rs.wasNull()) {
                        local.setDescuentoPorcentaje(0);
                    }

                    local.setFechaRegistro(rs.getTimestamp("fecha_registro"));

                    locales.add(local);
                }
            }

        } catch (SQLException e) {
            throw new Exception("Error al ejecutar la búsqueda de locales en la base de datos.", e);
        }

        return locales;
    }
}
