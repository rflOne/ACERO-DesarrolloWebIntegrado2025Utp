package com.calificacionlocales.dao.impl;

import com.calificacionlocales.dao.UsuarioDAO;
import com.calificacionlocales.dto.UsuarioDTO;
import com.calificacionlocales.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioDAOImpl implements UsuarioDAO {

    private static final Logger LOGGER = Logger.getLogger(UsuarioDAOImpl.class.getName());

    /**
     * Mapea un ResultSet a un UsuarioDTO, usando 'id_usuario' y 'puntos' de la
     * tabla de la base de datos.
     */
    private UsuarioDTO mapResultSetToDTO(ResultSet rs) throws SQLException {
        UsuarioDTO u = new UsuarioDTO();

        // --- CORRECCIÓN CLAVE: Usar id_usuario de la DB ---
        u.setId(rs.getInt("id_usuario"));

        u.setNombre(rs.getString("nombre"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setRol(rs.getString("rol"));

        // --- CORRECCIÓN CLAVE: Mapear el campo 'puntos' ---
        u.setPuntos(rs.getInt("puntos"));

        u.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        return u;
    }

    // --- CONTEO ---
    @Override
    public int countAll() throws Exception {
        String sql = "SELECT COUNT(*) FROM usuarios";
        int count = 0;

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al contar usuarios", e);
            throw new Exception("Error al obtener el conteo de usuarios.", e);
        }
        return count;
    }

    // --- ENCONTRAR TODOS ---
    @Override
    public List<UsuarioDTO> findAll() throws Exception {
        // CORRECCIÓN: Usar id_usuario y agregar puntos a la SELECT
        String sql = "SELECT id_usuario, nombre, email, password, rol, puntos, fecha_registro FROM usuarios ORDER BY id_usuario DESC";
        List<UsuarioDTO> list = new ArrayList<>();

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al buscar todos los usuarios", e);
            throw new Exception("Error al listar todos los usuarios.", e);
        }
        return list;
    }

    // --- ENCONTRAR POR ID ---
    @Override
    public UsuarioDTO findById(int id) throws Exception {
        // CORRECCIÓN: Usar id_usuario en SELECT y en la cláusula WHERE
        String sql = "SELECT id_usuario, nombre, email, password, rol, puntos, fecha_registro FROM usuarios WHERE id_usuario = ?";
        UsuarioDTO u = null;

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u = mapResultSetToDTO(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al buscar usuario por ID: " + id, e);
            throw new Exception("Error al buscar el usuario.", e);
        }
        return u;
    }

    // --- FILTRADO (Implementación clave para AdminUsuarioServlet) ---
    @Override
    public List<UsuarioDTO> findFiltered(String query, String rol) throws Exception {
        List<UsuarioDTO> users = new ArrayList<>();

        // CORRECCIÓN: Usar id_usuario y puntos en la SELECT
        StringBuilder sql = new StringBuilder(
                "SELECT id_usuario, nombre, email, password, rol, puntos, fecha_registro FROM usuarios WHERE 1=1"
        );

        List<Object> params = new ArrayList<>();

        // 1. FILTRO DE BÚSQUEDA POR TEXTO (Nombre o Email)
        boolean hasQuery = query != null && !query.trim().isEmpty();
        if (hasQuery) {
            sql.append(" AND (LOWER(nombre) LIKE ? OR LOWER(email) LIKE ?)");
            String searchPattern = "%" + query.trim().toLowerCase() + "%";
            params.add(searchPattern);
            params.add(searchPattern);
        }

        // 2. FILTRO POR ROL
        boolean hasRol = rol != null && !rol.trim().isEmpty();
        if (hasRol) {
            sql.append(" AND rol = ?");
            params.add(rol);
        }

        // 3. ORDENACIÓN
        sql.append(" ORDER BY id_usuario DESC");

        // Ejecución de la consulta
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql.toString())) {

            // Asignar los parámetros dinámicamente
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    users.add(mapResultSetToDTO(rs));
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al ejecutar la búsqueda de usuarios filtrada", e);
            throw new Exception("Error al ejecutar la búsqueda de usuarios en la base de datos.", e);
        }

        return users;
    }

    // --- AUTENTICACIÓN ---
    @Override
    public UsuarioDTO findByEmailAndPassword(String email, String password) throws Exception {
        // CORRECCIÓN: Usar id_usuario y puntos
        String sql = "SELECT id_usuario, nombre, email, password, rol, puntos, fecha_registro FROM usuarios WHERE email = ? AND password = ?";
        UsuarioDTO u = null;

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u = mapResultSetToDTO(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al autenticar usuario con email: " + email, e);
            throw new Exception("Error al autenticar el usuario.", e);
        }
        return u;
    }

    // --- Métodos CRUD (Debes implementarlos completamente) ---
    @Override
    public boolean save(UsuarioDTO usuario) throws Exception {
        // CORRECCIÓN: Usar id_usuario y puntos en el INSERT
        String sql = "INSERT INTO usuarios (nombre, email, password, rol, puntos) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol());
            ps.setInt(5, usuario.getPuntos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al guardar usuario", e);
            throw new Exception("Error al guardar el usuario.", e);
        }
    }

    @Override
    public boolean update(UsuarioDTO usuario) throws Exception {
        // CORRECCIÓN: Usar id_usuario y puntos en el UPDATE
        String sql = "UPDATE usuarios SET nombre=?, email=?, password=?, rol=?, puntos=? WHERE id_usuario=?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getPassword());
            ps.setString(4, usuario.getRol());
            ps.setInt(5, usuario.getPuntos());
            ps.setInt(6, usuario.getId()); // Filtro por el ID
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al actualizar usuario", e);
            throw new Exception("Error al actualizar el usuario.", e);
        }
    }

    @Override
    public boolean delete(int id) throws Exception {
        // CORRECCIÓN: Usar id_usuario en el DELETE
        String sql = "DELETE FROM usuarios WHERE id_usuario = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error SQL al eliminar usuario", e);
            throw new Exception("Error al eliminar el usuario.", e);
        }
    }
}
