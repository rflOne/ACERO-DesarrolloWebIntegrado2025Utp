package com.calificacionlocales.dao.impl;

import com.calificacionlocales.dao.ValoracionDAO;
import com.calificacionlocales.dto.ValoracionDTO;
import com.calificacionlocales.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ValoracionDAOImpl implements ValoracionDAO {

    @Override
    public boolean save(ValoracionDTO v) throws Exception {
        String sql = "INSERT INTO valoraciones (local_id, usuario_id, comentario, puntaje) VALUES (?, ?, ?, ?)";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, v.getLocalId());
            ps.setInt(2, v.getUsuarioId());
            ps.setString(3, v.getComentario());
            ps.setInt(4, v.getPuntaje());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public List<ValoracionDTO> findByLocalId(int localId) throws Exception {
        String sql = "SELECT * FROM valoraciones WHERE local_id = ? ORDER BY fecha DESC";
        List<ValoracionDTO> list = new ArrayList<>();
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, localId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ValoracionDTO v = new ValoracionDTO();
                    v.setId(rs.getInt("id"));
                    v.setLocalId(rs.getInt("local_id"));
                    v.setUsuarioId(rs.getInt("usuario_id"));
                    v.setComentario(rs.getString("comentario"));
                    v.setPuntaje(rs.getInt("puntaje"));
                    v.setFecha(rs.getTimestamp("fecha"));
                    list.add(v);
                }
            }
        }
        return list;
    }

    @Override
    public double calcularPromedio(int localId) throws Exception {
        String sql = "SELECT AVG(puntaje) AS promedio FROM valoraciones WHERE local_id = ?";
        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, localId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("promedio");
                }
            }
        }
        return 0;
    }

    @Override
    public boolean deleteByLocalId(int localId) throws Exception {
        String sql = "DELETE FROM valoraciones WHERE local_id = ?";

        try (Connection c = DBUtil.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, localId);
            ps.executeUpdate();
            // Nota: Devolvemos 'true' si no hay excepción, incluso si rows=0 (significa que no había valoraciones).
            return true;

        } catch (SQLException e) {
            throw new Exception("Error al eliminar las valoraciones del local ID: " + localId, e);
        }
    }
}
