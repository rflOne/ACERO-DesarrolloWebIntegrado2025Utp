package com.calificacionlocales.dao;

import com.calificacionlocales.dto.UsuarioDTO;
import java.util.List;

public interface UsuarioDAO {

    // Operaciones CRUD
    boolean save(UsuarioDTO usuario) throws Exception;

    boolean update(UsuarioDTO usuario) throws Exception;

    boolean delete(int id) throws Exception;

    // Operaciones de Lectura
    UsuarioDTO findById(int id) throws Exception;

    List<UsuarioDTO> findAll() throws Exception;

    // Operaciones de Búsqueda y Conteo
    int countAll() throws Exception;

    // Método para soportar los filtros del AdminUsuarioServlet
    List<UsuarioDTO> findFiltered(String query, String rol) throws Exception;

    // Método de autenticación (útil para el login)
    UsuarioDTO findByEmailAndPassword(String email, String password) throws Exception;
}
