package com.calificacionlocales.dao;

import com.calificacionlocales.dto.ValoracionDTO;
import java.util.List;

public interface ValoracionDAO {

    boolean save(ValoracionDTO valoracion) throws Exception;

    List<ValoracionDTO> findByLocalId(int localId) throws Exception;

    double calcularPromedio(int localId) throws Exception;
    
    public boolean deleteByLocalId(int localId) throws Exception;
}
