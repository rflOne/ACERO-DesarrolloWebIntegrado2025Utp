package com.calificacionlocales.fachada;

import com.calificacionlocales.dao.LocalDAO;
import com.calificacionlocales.dao.UsuarioDAO;
import com.calificacionlocales.dao.impl.LocalDAOImpl; // Importamos la implementación concreta
import com.calificacionlocales.dao.impl.UsuarioDAOImpl;
import com.calificacionlocales.dto.LocalDTO;
import com.calificacionlocales.dao.impl.ValoracionDAOImpl;
import com.calificacionlocales.dto.UsuarioDTO;
import java.util.List;

public class AppFacade {

    // 1. Instancia Singleton
    private static AppFacade instance;

    // 2. Referencia a la Interfaz DAO (Usando la implementación concreta)
    private final LocalDAO localDAO;

    /**
     * Constructor privado (patrón Singleton). Instancia el DAO.
     */
    private AppFacade() {
        // En un entorno más avanzado se usaría Inyección de Dependencias, 
        // pero aquí instanciamos la implementación concreta.
        this.localDAO = new LocalDAOImpl();
    }

    /**
     * Devuelve la única instancia de AppFacade (Singleton).
     *
     * @return La instancia de AppFacade.
     */
    public static AppFacade getInstance() {
        if (instance == null) {
            instance = new AppFacade();
        }
        return instance;
    }

    // ----------------------------------------------------
    // MÉTODO DE NEGOCIO: REGISTRO DE LOCAL
    // ----------------------------------------------------
    /**
     * Intenta guardar un nuevo LocalDTO en la base de datos a través del DAO.
     * Aquí se puede agregar cualquier lógica de negocio (validaciones).
     *
     * * @param local El DTO del local con los datos, incluyendo la ruta de la
     * imagen.
     * @return true si el local fue guardado exitosamente.
     * @throws Exception Si ocurre un error de validación o de la capa de
     * persistencia (DAO).
     */
    public boolean registrarLocal(LocalDTO local) throws Exception {

        // ** (Opcional) Lógica de Negocio / Validación **
        if (local.getNombre() == null || local.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del local es obligatorio y no puede estar vacío.");
        }

        // Puedes agregar más validaciones aquí (ej: longitud de dirección, etc.)
        // 3. Llamada a la capa de Persistencia (DAO)
        try {
            // Utilizamos el método save() de tu interfaz LocalDAO
            return localDAO.save(local);

        } catch (Exception e) {
            // Aquí manejas (o relanzas) cualquier error que venga del DAO (ej: SQLException)
            System.err.println("Façade Error al registrar local: " + e.getMessage());
            throw new Exception("Fallo al completar el registro del local debido a un error interno.", e);
        }
    }

    // ----------------------------------------------------
    // Otros métodos de negocio (ej: obtener locales, listar usuarios) irían aquí...
    // ----------------------------------------------------
    public int contarLocales() throws Exception {
        LocalDAOImpl localDAO = new LocalDAOImpl();
        return localDAO.countAll();
    }

    public int contarUsuarios() throws Exception {
        UsuarioDAOImpl usuarioDAO = new UsuarioDAOImpl(); // o usa inyección/fábrica
        return usuarioDAO.countAll();
    }

    public List<LocalDTO> listarUltimosLocales(int limit) throws Exception {
        LocalDAOImpl localDAO = new LocalDAOImpl();
        return localDAO.findLatest(limit);
    }

    public LocalDTO obtenerLocalPorId(int id) throws Exception {
        LocalDAOImpl localDAO = new LocalDAOImpl();
        return localDAO.findById(id); // Asume que LocalDAOImpl ya tiene findById(int id)
    }

    public boolean actualizarLocal(LocalDTO local) throws Exception {
        LocalDAOImpl localDAO = new LocalDAOImpl();
        return localDAO.update(local);
    }

    public boolean eliminarLocalYValoraciones(int localId) throws Exception {
        ValoracionDAOImpl valoracionDAO = new ValoracionDAOImpl();
        LocalDAOImpl localDAO = new LocalDAOImpl();

        try {
            // 1. ELIMINAR LAS VALORACIONES ASOCIADAS (obligatorio primero)
            valoracionDAO.deleteByLocalId(localId);

            // 2. ELIMINAR EL LOCAL
            boolean localEliminado = localDAO.delete(localId); // Asume que LocalDAO tiene un método delete(int id)

            // 3. (OPCIONAL) Lógica para eliminar el archivo de imagen del servidor 
            // Esta lógica es compleja y es mejor dejarla en el Servlet, como se vio en la respuesta anterior.
            return localEliminado;

        } catch (Exception e) {
            // Manejo de excepción (deberías considerar la lógica de rollback si usaras transacciones explícitas)
            throw new Exception("Fallo en la eliminación en cascada del local ID: " + localId, e);
        }

    }

    public List<LocalDTO> getAllLocales() throws Exception {
        // Delega la llamada directamente al DAO
        return localDAO.findAll();
    }

    public List<LocalDTO> getAllLocales(String query, Double maxPrice) throws Exception {
        // Delega la llamada al nuevo método de filtrado del DAO
        return localDAO.findFiltered(query, maxPrice);
    }

    ////usuariooo
    // AppFacade.java (Fragmento, asume que tienes el DAO ya inyectado)
// Dentro de AppFacade:
    private final UsuarioDAO usuarioDAO = new UsuarioDAOImpl(); // Instancia el DAO

// Agrega estos métodos:
    public List<UsuarioDTO> getAllUsuarios() throws Exception {
        return usuarioDAO.findAll();
    }

    public List<UsuarioDTO> getAllUsuarios(String query, String rol) throws Exception {
        return usuarioDAO.findFiltered(query, rol);
    }

// Otros métodos necesarios:
    public UsuarioDTO getUsuarioById(int id) throws Exception {
        return usuarioDAO.findById(id);
    }

    public boolean registrarUsuario(UsuarioDTO usuario) throws Exception {
        return usuarioDAO.save(usuario);
    }

    public boolean actualizarUsuario(UsuarioDTO usuario) throws Exception {
        return usuarioDAO.update(usuario);
    }

    public boolean eliminarUsuario(int id) throws Exception {
        return usuarioDAO.delete(id);
    }
}
